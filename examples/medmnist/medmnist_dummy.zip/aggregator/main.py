"""MedMNIST aggregator for PyTorch."""

import logging

from flame.config import Config
from flame.dataset import Dataset  # Not sure why we need this.
from flame.mode.horizontal.top_aggregator import TopAggregator
import torch
import torchvision

logger = logging.getLogger(__name__)


class PyTorchMedMNistAggregator(TopAggregator):
    """PyTorch MedMNist Aggregator"""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.model = None
        self.dataset: Dataset = None  # Not sure why we need this.

    def initialize(self):
        """Initialize."""
        self.model = torchvision.models.resnet50()

    def load_data(self) -> None:
        """Load a test dataset."""
        # Implement this if loading data is needed in aggregator
        pass

    def train(self) -> None:
        """Train a model."""
        # Implement this if training is needed in aggregator
        pass

    def evaluate(self) -> None:
        """Evaluate (test) a model."""
        # Implement this if testing is needed in aggregator
        pass


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='')
    parser.add_argument('config', nargs='?', default="./config.json")

    args = parser.parse_args()

    config = Config(args.config)

    a = PyTorchMedMNistAggregator(config)
    a.compose()
    a.run()
